@echo off
setlocal
chcp 65001 >nul
cd /d D:\137codex\137capemaker\MotionPNGTuber
.venv\Scripts\python.exe loop_lipsync_runtime_patched_emotion_auto.py --assets-dir "D:\137codex\137capemaker\.cape-work\motionpngtuber\boyish-motionpngtuber\motionpngtuber_ready" --loop-video "D:\137codex\137capemaker\.cape-work\motionpngtuber\boyish-motionpngtuber\motionpngtuber_ready\loop.mp4" --mouth-dir "D:\137codex\137capemaker\.cape-work\motionpngtuber\boyish-motionpngtuber\motionpngtuber_ready\mouth" --track "D:\137codex\137capemaker\.cape-work\motionpngtuber\boyish-motionpngtuber\motionpngtuber_ready\mouth_track.npz" --no-emotion-gui --mouth-brightness 0 --mouth-saturation 1.0 --mouth-warmth 0 --mouth-color-strength 0.75 --mouth-edge-priority 0.85 --mouth-edge-width-ratio 0.10 --window-name "CapeMaker boyish MotionPNGTuber Ready"
